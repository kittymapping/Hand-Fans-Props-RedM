Kitty Hand fans PROPS | RedM

This package includes custom-made hand fans in 7 different textures.

Prop names:
k_h_handfan_01
k_h_handfan_02
k_h_handfan_03
k_h_handfan_04
k_h_handfan_05
k_h_handfan_06
k_h_handfan_07

Texture file: k_h_handfan_txd.ytd
YTYP file: k_h_handfan.ytyp

Installation for the props: 
	      1. Unzip the file and drag into your resources.
	      2. Ensure the resource.

Each of the props can be placed with Spooner.
	      1. Open Spooner
              2. Go to Objects
              3. Type the correct name of the prop
              4. Go to "Spawn by name"
              5. Press "E" on your keyboard
